#!bin/bash

# OpenGL
sudo apt-get install -y mesa-common-dev libglu1-mesa-dev freeglut3-dev

# Linear Algebra
sudo apt-get install -y libsuitesparse-dev

# build
make
