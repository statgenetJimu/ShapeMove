# Warning
This folder was copied and modified from https://github.com/dgpdec/course/tree/master/Fairing

# 使い方
* Ubuntuのvagrant boxあるいはそれに準じた環境を用意する
* ``sh install_fairing.sh``を実行する
